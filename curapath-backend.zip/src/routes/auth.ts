import { Router, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import { createHash, randomBytes, randomInt } from 'crypto';
import { v4 as uuidv4 } from 'uuid';
import { SESClient, SendEmailCommand } from '@aws-sdk/client-ses';
import pool from '../db';
import { requireAuth, AuthRequest } from '../middleware/auth';

const ses = new SESClient({ region: process.env.AWS_REGION ?? 'us-east-2' });

const router = Router();
const BCRYPT_ROUNDS = 12;

async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, BCRYPT_ROUNDS);
}

async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

function signAccess(userId: string): string {
  return jwt.sign({ sub: userId }, process.env.JWT_SECRET!, {
    expiresIn: (process.env.JWT_EXPIRY ?? '1h') as jwt.SignOptions['expiresIn'],
  });
}

function signRefresh(): string {
  return randomBytes(64).toString('hex');
}

// POST /auth/register
router.post('/register', async (req: Request, res: Response): Promise<void> => {
  const { email, password, timezone, firstName, lastName } = req.body as {
    email?: string;
    password?: string;
    timezone?: string;
    firstName?: string;
    lastName?: string;
  };

  if (!email || !password || !firstName) {
    res.status(400).json({ error: 'first name, email, and password are required' });
    return;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    res.status(400).json({ error: 'Invalid email address' });
    return;
  }

  try {
    const result = await pool.query(
      `INSERT INTO users (id, email, password_hash, first_name, last_name, timezone)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, email, first_name, last_name, timezone, created_at`,
      [uuidv4(), email.toLowerCase(), await hashPassword(password), firstName.trim(), lastName?.trim() ?? null, timezone ?? 'America/New_York']
    );

    const user = result.rows[0];
    const accessToken = signAccess(user.id);
    const refreshToken = signRefresh();

    await pool.query(
      `INSERT INTO refresh_tokens (id, user_id, token_hash, expires_at)
       VALUES ($1, $2, $3, NOW() + INTERVAL '30 days')`,
      [uuidv4(), user.id, createHash('sha256').update(refreshToken).digest('hex')]
    );

    res.status(201).json({ data: { user, accessToken, refreshToken } });
  } catch (err: any) {
    if (err.code === '23505') {
      res.status(409).json({ error: 'Email already registered' });
      return;
    }
    console.error('Register error', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /auth/login
router.post('/login', async (req: Request, res: Response): Promise<void> => {
  const { email, password } = req.body as { email?: string; password?: string };

  if (!email || !password) {
    res.status(400).json({ error: 'email and password are required' });
    return;
  }

  try {
    const result = await pool.query(
      `SELECT id, email, first_name, last_name, timezone, created_at, password_hash FROM users WHERE email = $1`,
      [email.toLowerCase()]
    );

    const user = result.rows[0];
    if (!user || !await verifyPassword(password, user.password_hash)) {
      res.status(401).json({ error: 'Invalid credentials' });
      return;
    }

    const accessToken = signAccess(user.id);
    const refreshToken = signRefresh();

    await pool.query(
      `INSERT INTO refresh_tokens (id, user_id, token_hash, expires_at)
       VALUES ($1, $2, $3, NOW() + INTERVAL '30 days')`,
      [uuidv4(), user.id, createHash('sha256').update(refreshToken).digest('hex')]
    );

    const { password_hash: _, ...userPublic } = user;
    res.json({ data: { user: userPublic, accessToken, refreshToken } });
  } catch (err) {
    console.error('Login error', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /auth/refresh
router.post('/refresh', async (req: Request, res: Response): Promise<void> => {
  const { refreshToken } = req.body as { refreshToken?: string };
  if (!refreshToken) {
    res.status(400).json({ error: 'refreshToken is required' });
    return;
  }

  const tokenHash = createHash('sha256').update(refreshToken).digest('hex');

  try {
    const result = await pool.query(
      `SELECT user_id FROM refresh_tokens
       WHERE token_hash = $1 AND expires_at > NOW()`,
      [tokenHash]
    );

    if (!result.rows[0]) {
      res.status(401).json({ error: 'Invalid or expired refresh token' });
      return;
    }

    const { user_id } = result.rows[0];

    // Rotate refresh token
    await pool.query(`DELETE FROM refresh_tokens WHERE token_hash = $1`, [tokenHash]);
    const newRefreshToken = signRefresh();
    await pool.query(
      `INSERT INTO refresh_tokens (id, user_id, token_hash, expires_at)
       VALUES ($1, $2, $3, NOW() + INTERVAL '30 days')`,
      [uuidv4(), user_id, createHash('sha256').update(newRefreshToken).digest('hex')]
    );

    res.json({
      data: {
        accessToken: signAccess(user_id),
        refreshToken: newRefreshToken,
      },
    });
  } catch (err) {
    console.error('Refresh error', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /auth/forgot-password
router.post('/forgot-password', async (req: Request, res: Response): Promise<void> => {
  const { email } = req.body as { email?: string };
  if (!email) { res.status(400).json({ error: 'email is required' }); return; }

  try {
    const result = await pool.query(`SELECT id FROM users WHERE email = $1`, [email.toLowerCase()]);
    // Always return success to prevent email enumeration
    if (!result.rows[0]) { res.json({ data: { sent: true } }); return; }

    const userId = result.rows[0].id;
    const code = String(randomInt(100000, 999999));
    const codeHash = createHash('sha256').update(code).digest('hex');

    await pool.query(`DELETE FROM password_reset_tokens WHERE user_id = $1`, [userId]);
    await pool.query(
      `INSERT INTO password_reset_tokens (id, user_id, code_hash, expires_at)
       VALUES ($1, $2, $3, NOW() + INTERVAL '15 minutes')`,
      [uuidv4(), userId, codeHash]
    );

    await ses.send(new SendEmailCommand({
      Source: 'noreply@curapath.app',
      Destination: { ToAddresses: [email] },
      Message: {
        Subject: { Data: 'Your CuraPath password reset code' },
        Body: {
          Text: {
            Data: `Your CuraPath password reset code is: ${code}\n\nThis code expires in 15 minutes.\n\nIf you didn't request this, you can ignore this email.`,
          },
        },
      },
    }));

    res.json({ data: { sent: true } });
  } catch (err) {
    console.error('Forgot password error', err);
    res.json({ data: { sent: true } }); // Always succeed to client
  }
});

// POST /auth/reset-password
router.post('/reset-password', async (req: Request, res: Response): Promise<void> => {
  const { email, code, newPassword } = req.body as { email?: string; code?: string; newPassword?: string };
  if (!email || !code || !newPassword) {
    res.status(400).json({ error: 'email, code, and newPassword are required' });
    return;
  }
  if (newPassword.length < 8) {
    res.status(400).json({ error: 'Password must be at least 8 characters' });
    return;
  }

  try {
    const userResult = await pool.query(`SELECT id FROM users WHERE email = $1`, [email.toLowerCase()]);
    if (!userResult.rows[0]) { res.status(400).json({ error: 'Invalid code' }); return; }

    const userId = userResult.rows[0].id;
    const codeHash = createHash('sha256').update(code).digest('hex');

    const tokenResult = await pool.query(
      `SELECT id FROM password_reset_tokens
       WHERE user_id = $1 AND code_hash = $2 AND expires_at > NOW() AND used = false`,
      [userId, codeHash]
    );

    if (!tokenResult.rows[0]) { res.status(400).json({ error: 'Invalid or expired code' }); return; }

    await pool.query(`UPDATE password_reset_tokens SET used = true WHERE id = $1`, [tokenResult.rows[0].id]);
    await pool.query(`UPDATE users SET password_hash = $1 WHERE id = $2`, [await hashPassword(newPassword), userId]);
    await pool.query(`DELETE FROM refresh_tokens WHERE user_id = $1`, [userId]);

    res.json({ data: { reset: true } });
  } catch (err) {
    console.error('Reset password error', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// DELETE /auth/account
router.delete('/account', requireAuth, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    await pool.query(`DELETE FROM users WHERE id = $1`, [req.userId]);
    res.json({ data: { deleted: true } });
  } catch (err) {
    console.error('Delete account error', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
